package fr.orsys.msa.gestionclient.gestionclientgraphql.graphql;

import com.coxautodev.graphql.tools.GraphQLQueryResolver;
import fr.orsys.msa.gestionclient.gestionclientgraphql.service.Client;
import fr.orsys.msa.gestionclient.gestionclientgraphql.service.ClientService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.Arrays;
import java.util.List;

@Component
public class ClientResolver implements GraphQLQueryResolver {

    @Autowired
    ClientService clientService;

    public List<Client> clients(){
        return clientService.getClients();
    }

}
