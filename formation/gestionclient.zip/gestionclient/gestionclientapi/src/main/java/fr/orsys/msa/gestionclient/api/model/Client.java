package fr.orsys.msa.gestionclient.api.model;

import lombok.Data;

import javax.persistence.Entity;
import javax.persistence.Id;

@Data
@Entity
public class Client {

    @Id
    private Long id;

    private String firstname;
    private String lastname;
    private String address;
    private String city;
    private String zipCode;
}
