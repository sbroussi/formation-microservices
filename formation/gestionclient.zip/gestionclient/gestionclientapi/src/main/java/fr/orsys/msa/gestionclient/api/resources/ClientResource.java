package fr.orsys.msa.gestionclient.api.resources;

import fr.orsys.msa.gestionclient.api.config.AppConfig;
import fr.orsys.msa.gestionclient.api.data.ClientRepository;
import fr.orsys.msa.gestionclient.api.model.Client;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.io.FileSystemResource;
import org.springframework.core.io.Resource;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.*;

import java.util.Arrays;
import java.util.List;

@RestController
@RequestMapping("/api/clients")
@CrossOrigin
public class ClientResource {

    @Autowired
    private ClientRepository clientRepository;

    @Autowired
    private AppConfig appConfig;

    @Value("${app.pictures.directory}")
    private String directory;

    @GetMapping
    public List<Client> getClients(){
        return clientRepository.findAll();
    }

    @GetMapping(value = "/{id}/picture" ,
        produces = {MediaType.IMAGE_PNG_VALUE, MediaType.IMAGE_JPEG_VALUE})
    public Resource getPicture(@PathVariable Long id){
//        String directory = appConfig.getPictures().getDirectory();
        FileSystemResource picture = new FileSystemResource(directory + "/" + id + ".jpg");
        if(!picture.exists()){
            picture = new FileSystemResource(directory + "/" + id + ".png");
        }
        return picture;
    }
}
