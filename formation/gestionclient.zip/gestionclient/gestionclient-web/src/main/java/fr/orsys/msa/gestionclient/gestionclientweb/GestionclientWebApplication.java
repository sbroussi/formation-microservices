package fr.orsys.msa.gestionclient.gestionclientweb;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.netflix.feign.EnableFeignClients;

@SpringBootApplication
@EnableFeignClients
public class GestionclientWebApplication {

	public static void main(String[] args) {
		SpringApplication.run(GestionclientWebApplication.class, args);
	}

}

