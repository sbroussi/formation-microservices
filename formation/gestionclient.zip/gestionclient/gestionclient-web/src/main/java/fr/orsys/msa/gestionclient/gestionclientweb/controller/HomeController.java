package fr.orsys.msa.gestionclient.gestionclientweb.controller;

import fr.orsys.msa.gestionclient.gestionclientweb.service.Client;
import fr.orsys.msa.gestionclient.gestionclientweb.service.ClientService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

import java.util.List;

@Controller
public class HomeController {

    @Autowired
    ClientService clientService;

    @GetMapping("/")
    public String index(Model model){
        List<Client> clients = clientService.getClients();
        model.addAttribute("clients", clients);
        return "index";
    }
}
